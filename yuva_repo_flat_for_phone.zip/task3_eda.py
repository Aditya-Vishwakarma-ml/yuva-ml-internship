# %% [markdown]
# # Task 3: Real-World Dataset Analysis Project
# Dataset: Breast Cancer Wisconsin (Diagnostic) - 569 samples, 30 numeric features from digitised images of fine-needle aspirates. Source: UCI repository (shipped with scikit-learn).

# %%
import os, numpy as np, pandas as pd, seaborn as sns, matplotlib.pyplot as plt
from scipy import stats
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
os.makedirs("figures", exist_ok=True); sns.set_theme(style="whitegrid")

# %% [markdown]
# ## 1. Load and inspect

# %%
data = load_breast_cancer(as_frame=True)
df = data.frame.copy()
df["diagnosis"] = df["target"].map({0: "malignant", 1: "benign"})
print("shape:", df.shape)
print(df.dtypes.value_counts())
print(df.describe().T[["mean", "std", "min", "50%", "max"]].head(10).round(3))

# %% [markdown]
# ## 2. Data quality and cleaning

# %%
print("missing values :", int(df.isna().sum().sum()))
print("duplicate rows :", int(df.duplicated().sum()))
feat = list(data.feature_names)

q1, q3 = df[feat].quantile(.25), df[feat].quantile(.75); iqr = q3 - q1
mask = (df[feat] < q1 - 1.5 * iqr) | (df[feat] > q3 + 1.5 * iqr)
print("\nFeatures with most IQR outliers:\n", mask.sum().sort_values(ascending=False).head(5))
print("rows with at least one outlier:", int(mask.any(axis=1).sum()))

sk = df[feat].skew().sort_values(ascending=False)
print("\nMost skewed features:\n", sk.head(5).round(2))

# %% [markdown]
# ## 3. Preprocessing

# %%
skewed = sk[sk > 1].index.tolist()
df_clean = df.copy()
df_clean[skewed] = np.log1p(df_clean[skewed])
print("skewed columns transformed:", len(skewed))
print("mean |skew| before/after:", round(df[skewed].skew().abs().mean(), 3), "->", round(df_clean[skewed].skew().abs().mean(), 3))

corr = df_clean[feat].corr().abs()
upper = corr.where(np.triu(np.ones(corr.shape), k=1).astype(bool))
drop = [c for c in upper.columns if (upper[c] > 0.95).any()]
print("features dropped for multicollinearity:", len(drop), "->", drop)
kept = [c for c in feat if c not in drop]

Xs = StandardScaler().fit_transform(df_clean[kept])
print("final feature matrix:", Xs.shape, "| mean ~", round(float(Xs.mean()), 6), "| std ~", round(float(Xs.std()), 3))

# %% [markdown]
# ## 4. Exploratory analysis

# %%
print(df["diagnosis"].value_counts())
print((df["diagnosis"].value_counts(normalize=True) * 100).round(1))

rows = []
for f in feat:
    m, b = df.loc[df.diagnosis == "malignant", f], df.loc[df.diagnosis == "benign", f]
    sp = np.sqrt(((len(m)-1)*m.var() + (len(b)-1)*b.var()) / (len(m)+len(b)-2))
    rows.append((f, m.mean(), b.mean(), (m.mean()-b.mean())/sp, stats.ttest_ind(m, b, equal_var=False).pvalue))
eff = pd.DataFrame(rows, columns=["feature", "malignant_mean", "benign_mean", "cohens_d", "p_value"])
eff["abs_d"] = eff.cohens_d.abs(); eff = eff.sort_values("abs_d", ascending=False)
print(eff.head(8).round(3).to_string(index=False))
print("features with p < 0.05:", int((eff.p_value < .05).sum()), "of", len(eff))
eff.to_csv("effect_sizes.csv", index=False)

# %% [markdown]
# ## 5. Visualisations

# %%
fig, ax = plt.subplots(1, 3, figsize=(14, 4))
df.diagnosis.value_counts().plot.bar(ax=ax[0], color=["#2a9d8f", "#e76f51"], rot=0); ax[0].set_title("Class balance")
sns.violinplot(df, x="diagnosis", y="mean concave points", ax=ax[1]); ax[1].set_title("Mean concave points")
sns.boxplot(df, x="diagnosis", y="worst perimeter", ax=ax[2]); ax[2].set_title("Worst perimeter")
plt.tight_layout(); plt.savefig("figures/eda_distributions.png", dpi=130); plt.show()

top = eff.head(10).feature.tolist()
plt.figure(figsize=(8, 6.5)); sns.heatmap(df[top].corr(), annot=True, fmt=".2f", cmap="coolwarm", vmin=-1, vmax=1, annot_kws={"size": 7})
plt.title("Correlation among the 10 most discriminative features"); plt.tight_layout(); plt.savefig("figures/eda_heatmap.png", dpi=130); plt.show()

plt.figure(figsize=(7, 4.5)); sns.barplot(eff.head(10), y="feature", x="abs_d", color="#457b9d")
plt.title("Top 10 features by effect size (|Cohen's d|)"); plt.tight_layout(); plt.savefig("figures/eda_effect_size.png", dpi=130); plt.show()

pca = PCA(n_components=2).fit(Xs); P = pca.transform(Xs)
print("PCA explained variance (PC1, PC2):", pca.explained_variance_ratio_.round(3), "total", round(pca.explained_variance_ratio_.sum(), 3))
plt.figure(figsize=(6.5, 5)); sns.scatterplot(x=P[:, 0], y=P[:, 1], hue=df.diagnosis, alpha=.7)
plt.xlabel("PC1"); plt.ylabel("PC2"); plt.title("PCA projection of cleaned data"); plt.tight_layout(); plt.savefig("figures/eda_pca.png", dpi=130); plt.show()

# %%
df_clean.drop(columns=["target"]).to_csv("cleaned_breast_cancer.csv", index=False)
print("saved cleaned_breast_cancer.csv", df_clean.shape)
