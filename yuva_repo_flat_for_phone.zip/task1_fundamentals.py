# %% [markdown]
# # Task 1: Data Science Fundamentals Assessment
# Python basics, data types, statistics and best practices.
# Dataset used for the statistics part: Breast Cancer Wisconsin (Diagnostic), loaded from scikit-learn.

# %%
import random
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.datasets import load_breast_cancer

SEED = 42
random.seed(SEED); np.random.seed(SEED)

# %% [markdown]
# ## Part A: Python basics

# %%
age, gpa, name, is_student = 20, 8.1, "Aditya", True
print(type(age).__name__, type(gpa).__name__, type(name).__name__, type(is_student).__name__)

marks = [78, 85, 92, 66, 85, 71]            # list
point = (28.6, 77.2)                        # tuple
unique_marks = set(marks)                   # set
student = {"name": name, "marks": marks}    # dict
print("list:", marks); print("tuple:", point); print("set:", sorted(unique_marks)); print("dict keys:", list(student))

def grade(m: int) -> str:
    """Return a letter grade for a mark."""
    return "A" if m >= 85 else "B" if m >= 70 else "C"

print([grade(m) for m in marks])
print({m: grade(m) for m in unique_marks if m > 80})

def safe_divide(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return float("nan")
print(safe_divide(10, 4), safe_divide(1, 0))

# %% [markdown]
# ## Part B: Data types in data science

# %%
demo = pd.DataFrame({
    "student_id": [101, 102, 103, 104],
    "branch": pd.Categorical(["CSE", "ECE", "CSE", "ME"]),
    "grade": pd.Categorical(["B", "A", "C", "A"], categories=["C","B","A"], ordered=True),
    "cgpa": [7.8, 8.9, 6.5, 9.1],
    "passed": [True, True, True, True],
    "joined": pd.to_datetime(["2024-08-01", "2024-08-01", "2024-08-02", "2024-08-03"]),
})
print(demo.dtypes)
print("\nOrdinal comparison grade > 'B':", (demo["grade"] > "B").tolist())

# %% [markdown]
# ## Part C: Statistical foundations

# %%
data = load_breast_cancer(as_frame=True)
df = data.frame.copy()
df["diagnosis"] = df["target"].map({0: "malignant", 1: "benign"})
x = df["mean radius"]

print("n        :", len(x))
print("mean     :", round(x.mean(), 3))
print("median   :", round(x.median(), 3))
print("mode     :", round(x.round(0).mode()[0], 1), "(rounded)")
print("variance :", round(x.var(), 3))
print("std dev  :", round(x.std(), 3))
q1, q3 = x.quantile([.25, .75]); print("Q1, Q3, IQR:", round(q1,3), round(q3,3), round(q3-q1,3))
print("skewness :", round(stats.skew(x), 3))
print("kurtosis :", round(stats.kurtosis(x), 3))
z = (x - x.mean()) / x.std()
print("values with |z| > 3:", int((z.abs() > 3).sum()))

# %%
r, p = stats.pearsonr(df["mean radius"], df["mean area"])
print(f"Pearson r (radius vs area) = {r:.3f}, p = {p:.2e}")
ci = stats.t.interval(0.95, len(x)-1, loc=x.mean(), scale=stats.sem(x))
print("95% CI for mean radius:", tuple(round(float(v), 3) for v in ci))

mal = df.loc[df.diagnosis == "malignant", "mean radius"]
ben = df.loc[df.diagnosis == "benign", "mean radius"]
t, p = stats.ttest_ind(mal, ben, equal_var=False)
print(f"Welch t-test: malignant mean={mal.mean():.2f}, benign mean={ben.mean():.2f}, t={t:.2f}, p={p:.2e}")
print("Reject H0 (equal means) at 5%:", p < 0.05)

means = [np.random.choice(x, 30).mean() for _ in range(2000)]
print(f"CLT: mean of sample means={np.mean(means):.3f}, std={np.std(means):.3f}, theory={x.std()/np.sqrt(30):.3f}")

# %% [markdown]
# ## Part D: Industry best practices (demonstrated)

# %%
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

X, y = data.data, data.target
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)
print("train/test:", X_tr.shape, X_te.shape, "| benign share train/test:", round(y_tr.mean(),3), round(y_te.mean(),3))
sc = StandardScaler().fit(X_tr)
print("train mean after scaling ~0:", round(float(sc.transform(X_tr).mean()), 6))
print("missing values:", int(df.isna().sum().sum()), "| duplicate rows:", int(df.duplicated().sum()))
