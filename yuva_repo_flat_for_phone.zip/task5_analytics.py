# %% [markdown]
# # Task 5: Analytics Report & Insights
# Business question: which measurements best separate malignant from benign samples, and how well can a simple rule or model support screening?

# %%
import os, json, numpy as np, pandas as pd, seaborn as sns, matplotlib.pyplot as plt
from scipy import stats
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix, recall_score, precision_score, accuracy_score
os.makedirs("figures", exist_ok=True); sns.set_theme(style="whitegrid")
data = load_breast_cancer(as_frame=True); df = data.frame.copy()
df["diagnosis"] = df["target"].map({0: "malignant", 1: "benign"})
F = {}

# %% [markdown]
# ## KPIs

# %%
F["n"] = len(df); F["features"] = 30
F["malignant"] = int((df.diagnosis == "malignant").sum()); F["benign"] = int((df.diagnosis == "benign").sum())
F["malignant_pct"] = round(F["malignant"] / F["n"] * 100, 1)
print(F)

# %% [markdown]
# ## Finding 1: size and shape features separate the groups

# %%
mal, ben = df[df.diagnosis == "malignant"], df[df.diagnosis == "benign"]
for f in ["mean radius", "mean area", "mean concave points", "worst perimeter"]:
    pct = (mal[f].mean() / ben[f].mean() - 1) * 100
    F[f"uplift_{f}"] = round(pct, 1)
    print(f"{f:<22} malignant {mal[f].mean():9.3f} vs benign {ben[f].mean():9.3f}  -> +{pct:.0f}%")

# %% [markdown]
# ## Finding 2: a single-feature screening rule

# %%
f = "worst concave points"
best = max(((t, ((df[f] >= t) == (df.diagnosis == "malignant")).mean()) for t in np.linspace(df[f].min(), df[f].max(), 300)), key=lambda z: z[1])
thr, acc = best
pred_m = df[f] >= thr
tp = int((pred_m & (df.diagnosis == "malignant")).sum()); fn = int((~pred_m & (df.diagnosis == "malignant")).sum())
F["rule_feature"] = f; F["rule_threshold"] = round(float(thr), 3); F["rule_accuracy"] = round(float(acc) * 100, 1)
F["rule_recall"] = round(tp / (tp + fn) * 100, 1)
print(F["rule_feature"], F["rule_threshold"], F["rule_accuracy"], F["rule_recall"])

# %% [markdown]
# ## Finding 3: a simple, interpretable model

# %%
X, y = data.data, data.target
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, stratify=y, random_state=42)
m = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)).fit(Xtr, ytr)
p = m.predict(Xte)
tn, fp, fn_, tp_ = confusion_matrix(yte, p).ravel()
# class 0 = malignant; report malignant-detection recall
F["model_accuracy"] = round(accuracy_score(yte, p) * 100, 1)
F["model_malignant_recall"] = round(float(tn / (tn + fp) * 100), 1)
F["model_malignant_precision"] = round(float(tn / (tn + fn_) * 100), 1)
F["missed_malignant"] = int(fp); F["false_alarms"] = int(fn_); F["test_n"] = int(len(yte))
print({k: v for k, v in F.items() if k.startswith("model") or k in ("missed_malignant", "false_alarms")})
coef = pd.Series(m[-1].coef_[0], index=data.feature_names).sort_values()
F["top_malignant_drivers"] = coef.head(3).index.tolist()
print("strongest drivers towards malignant:", F["top_malignant_drivers"])

# %% [markdown]
# ## Visuals for the report

# %%
fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
ax[0].pie([F["malignant"], F["benign"]], labels=["Malignant", "Benign"], autopct="%1.1f%%", colors=["#e76f51", "#2a9d8f"], startangle=90); ax[0].set_title("Case mix (n=569)")
names = ["mean radius", "mean area", "mean concave points", "worst perimeter"]
ax[1].barh(names, [F[f"uplift_{n}"] for n in names], color="#457b9d"); ax[1].set_title("% higher in malignant vs benign"); ax[1].set_xlabel("%")
sns.kdeplot(data=df, x="worst concave points", hue="diagnosis", fill=True, ax=ax[2]); ax[2].axvline(thr, ls="--", c="k"); ax[2].set_title("Screening rule threshold")
plt.tight_layout(); plt.savefig("figures/analytics_overview.png", dpi=130); plt.show()

plt.figure(figsize=(4.8, 4)); sns.heatmap(confusion_matrix(yte, p, labels=[0, 1]), annot=True, fmt="d", cmap="Blues", xticklabels=["pred malignant", "pred benign"], yticklabels=["true malignant", "true benign"])
plt.title("Logistic regression on held-out test set"); plt.tight_layout(); plt.savefig("figures/analytics_confusion.png", dpi=130); plt.show()
json.dump(F, open("findings.json", "w"), indent=2)
