# Task 6: Final Capstone
End-to-end ML pipeline: stratified split, scaling pipeline, baseline, 5 models, GridSearchCV, test evaluation, permutation importance.
Best model: SVM (RBF), test accuracy 98.2%, malignant recall 97.6%, ROC-AUC 0.9977. Files: `task6_capstone.py`, `.ipynb`, `results.json`, `best_model.joblib`.
