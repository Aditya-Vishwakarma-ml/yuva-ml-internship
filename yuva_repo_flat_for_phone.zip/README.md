# Machine Learning Engineer Internship - Yuva Intern (Nov-Dec 2026)

Work submitted by **Aditya Vishwakarma** (B.Tech CSE, REC Basti).

All tasks use the **Breast Cancer Wisconsin (Diagnostic)** dataset (569 samples, 30 features) that ships with scikit-learn, so no download is needed.

| Files starting with | Task |
|---|---|
| `task1` | Data Science Fundamentals Assessment |
| `task2` | Hands-On Data Lab Implementation |
| `task3` | Real-World Dataset Analysis Project (EDA + cleaning) |
| `task4` | Data Science Tool Mastery Project |
| `task5` | Analytics Report & Insights |
| `task6` | Final Capstone: end-to-end ML solution |

Files are prefixed task1 to task6. Each task has a .py script, a Jupyter notebook (.ipynb), output text and figure images.

## Run
```bash
pip install -r requirements.txt
cd task6_capstone && python task6_capstone.py
```
Results: SVM reaches 98.2% test accuracy and 97.6% malignant recall (see task 6).

*Educational project only. Not a medical diagnostic tool.*
