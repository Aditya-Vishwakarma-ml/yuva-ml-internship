# %% [markdown]
# # Task 6: Final Capstone - End-to-end ML solution
# Problem: classify breast masses as malignant or benign from 30 FNA image features.
# Pipeline: data -> split -> preprocessing -> baseline -> 5 models -> tuning -> evaluation -> interpretation.

# %%
import os, json, warnings, numpy as np, pandas as pd, seaborn as sns, matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, roc_auc_score,
                             confusion_matrix, roc_curve, classification_report)
from sklearn.inspection import permutation_importance
warnings.filterwarnings("ignore"); os.makedirs("figures", exist_ok=True); sns.set_theme(style="whitegrid")
SEED = 42; R = {}

# %% [markdown]
# ## 1. Data and split (stratified 80/20, test set untouched until the end)

# %%
data = load_breast_cancer(as_frame=True)
X, y = data.data, data.target          # target: 0 = malignant, 1 = benign
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, stratify=y, random_state=SEED)
print("train", Xtr.shape, "test", Xte.shape, "| benign share:", round(ytr.mean(), 3), round(yte.mean(), 3))
cv = StratifiedKFold(5, shuffle=True, random_state=SEED)

# %% [markdown]
# ## 2. Baseline and candidate models (5-fold CV on training data only)

# %%
models = {
    "Baseline (majority)": DummyClassifier(strategy="most_frequent"),
    "Logistic Regression": LogisticRegression(max_iter=2000),
    "KNN": KNeighborsClassifier(),
    "SVM (RBF)": SVC(probability=True, random_state=SEED),
    "Random Forest": RandomForestClassifier(n_estimators=300, random_state=SEED),
    "Gradient Boosting": GradientBoostingClassifier(random_state=SEED),
}
cv_rows = []
for name, clf in models.items():
    pipe = Pipeline([("scale", StandardScaler()), ("clf", clf)])
    acc = cross_val_score(pipe, Xtr, ytr, cv=cv, scoring="accuracy")
    auc = cross_val_score(pipe, Xtr, ytr, cv=cv, scoring="roc_auc")
    cv_rows.append((name, acc.mean(), acc.std(), auc.mean()))
cvdf = pd.DataFrame(cv_rows, columns=["model", "cv_accuracy", "cv_std", "cv_auc"]).round(4)
print(cvdf.to_string(index=False)); R["cv"] = cvdf.to_dict("records")

# %% [markdown]
# ## 3. Hyper-parameter tuning (GridSearchCV)

# %%
grids = {
    "Logistic Regression": (LogisticRegression(max_iter=2000), {"clf__C": [0.01, 0.1, 1, 10, 100]}),
    "SVM (RBF)": (SVC(probability=True, random_state=SEED), {"clf__C": [0.1, 1, 10, 100], "clf__gamma": ["scale", 0.01, 0.001]}),
    "Random Forest": (RandomForestClassifier(random_state=SEED), {"clf__n_estimators": [200, 400], "clf__max_depth": [None, 6, 12]}),
}
tuned = {}
for name, (clf, grid) in grids.items():
    gs = GridSearchCV(Pipeline([("scale", StandardScaler()), ("clf", clf)]), grid, cv=cv, scoring="roc_auc", n_jobs=-1).fit(Xtr, ytr)
    tuned[name] = gs.best_estimator_
    print(f"{name:<20} best params={gs.best_params_}  CV AUC={gs.best_score_:.4f}")
    R.setdefault("tuning", {})[name] = {"params": {k.split('__')[1]: str(v) for k, v in gs.best_params_.items()}, "cv_auc": round(gs.best_score_, 4)}

# %% [markdown]
# ## 4. Final evaluation on the held-out test set

# %%
rows = []; probs = {}
for name, est in tuned.items():
    est.fit(Xtr, ytr); p = est.predict(Xte); pr = est.predict_proba(Xte)[:, 1]; probs[name] = pr
    # malignant (class 0) is the class we most want to catch
    rows.append((name, accuracy_score(yte, p), precision_score(yte, p, pos_label=0), recall_score(yte, p, pos_label=0),
                 f1_score(yte, p, pos_label=0), roc_auc_score(yte, pr)))
res = pd.DataFrame(rows, columns=["model", "accuracy", "precision_malignant", "recall_malignant", "f1_malignant", "roc_auc"]).round(4)
print(res.to_string(index=False)); R["test"] = res.to_dict("records")

best_name = res.sort_values(["recall_malignant", "roc_auc"], ascending=False).iloc[0]["model"]
best = tuned[best_name]; pbest = best.predict(Xte)
R["best_model"] = best_name
tn, fp, fn, tp = confusion_matrix(yte, pbest, labels=[0, 1]).ravel()
R["confusion"] = {"malignant_correct": int(tn), "malignant_missed": int(fp), "benign_false_alarm": int(fn), "benign_correct": int(tp)}
print("\nBest model:", best_name); print(classification_report(yte, pbest, target_names=["malignant", "benign"], digits=3))

# %% [markdown]
# ## 5. Plots

# %%
fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))
sns.heatmap(confusion_matrix(yte, pbest, labels=[0, 1]), annot=True, fmt="d", cmap="Blues", ax=ax[0], xticklabels=["pred malignant", "pred benign"], yticklabels=["true malignant", "true benign"])
ax[0].set_title(f"Confusion matrix: {best_name}")
for name, pr in probs.items():
    fpr, tpr, _ = roc_curve(yte, pr); ax[1].plot(fpr, tpr, label=f"{name} (AUC {roc_auc_score(yte, pr):.3f})")
ax[1].plot([0, 1], [0, 1], "k--"); ax[1].set_xlabel("False positive rate"); ax[1].set_ylabel("True positive rate"); ax[1].set_title("ROC curves (test set)"); ax[1].legend(loc="lower right")
plt.tight_layout(); plt.savefig("figures/capstone_eval.png", dpi=130); plt.show()

plt.figure(figsize=(7, 4)); cvdf.sort_values("cv_accuracy").plot.barh(x="model", y="cv_accuracy", xerr="cv_std", legend=False, color="#457b9d", xlim=(0.5, 1.0))
plt.title("5-fold CV accuracy (training data)"); plt.tight_layout(); plt.savefig("figures/capstone_cv.png", dpi=130); plt.show()

# %% [markdown]
# ## 6. Interpretation (permutation importance)

# %%
pi = permutation_importance(best, Xte, yte, n_repeats=20, random_state=SEED, scoring="roc_auc")
imp = pd.Series(pi.importances_mean, index=X.columns).sort_values(ascending=False)
print(imp.head(8).round(4)); R["top_features"] = {k: round(float(v), 4) for k, v in imp.head(5).items()}
plt.figure(figsize=(7, 4)); imp.head(10)[::-1].plot.barh(color="#2a9d8f"); plt.title(f"Permutation importance ({best_name})"); plt.tight_layout(); plt.savefig("figures/capstone_importance.png", dpi=130); plt.show()

# %%
import joblib; joblib.dump(best, "best_model.joblib"); json.dump(R, open("results.json", "w"), indent=2, default=str)
print("saved best_model.joblib and results.json")
