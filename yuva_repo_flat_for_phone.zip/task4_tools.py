# %% [markdown]
# # Task 4: Data Science Tool Mastery Project
# Hands-on exercises with NumPy, Pandas, Matplotlib, Seaborn, SciPy and scikit-learn (portfolio piece).

# %%
import os, time, numpy as np, pandas as pd, seaborn as sns, matplotlib.pyplot as plt
from scipy import stats, optimize
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
os.makedirs("figures", exist_ok=True); sns.set_theme(style="whitegrid")

# %% [markdown]
# ## 1. NumPy: vectorisation vs loops

# %%
n = 1_000_000
a = np.random.default_rng(1).random(n); b = np.random.default_rng(2).random(n)
t0 = time.perf_counter(); s_loop = sum(x * y for x, y in zip(a, b)); t_loop = time.perf_counter() - t0
t0 = time.perf_counter(); s_vec = float(a @ b); t_vec = time.perf_counter() - t0
print(f"dot product loop={t_loop:.4f}s vectorised={t_vec:.6f}s speed-up ~{t_loop/t_vec:.0f}x | same result: {np.isclose(s_loop, s_vec)}")

A = np.array([[2., 1.], [1., 3.]]); rhs = np.array([8., 13.])
print("solve Ax=b ->", np.linalg.solve(A, rhs), "| eigenvalues:", np.round(np.linalg.eigvals(A), 3))
x = np.arange(5)[:, None] + np.arange(3)[None, :]
print("broadcasting result shape:", x.shape)

# %% [markdown]
# ## 2. Pandas: time series and cleaning

# %%
rng = np.random.default_rng(7)
idx = pd.date_range("2026-01-01", periods=120, freq="D")
sales = pd.DataFrame({"date": idx, "units": rng.poisson(40, 120), "city": rng.choice(["Delhi", "Lucknow", "Basti"], 120)})
sales.loc[rng.choice(120, 6, replace=False), "units"] = np.nan
print("missing before:", int(sales.units.isna().sum()))
sales["units"] = sales.groupby("city")["units"].transform(lambda s: s.fillna(s.median()))
print("missing after :", int(sales.units.isna().sum()))
monthly = sales.set_index("date").resample("MS")["units"].sum()
print(monthly)
print(sales.groupby("city").units.agg(["sum", "mean"]).round(1))
sales["rolling7"] = sales["units"].rolling(7).mean()

# %% [markdown]
# ## 3. SciPy: statistics and optimisation

# %%
data = load_breast_cancer(as_frame=True)
df = data.frame.copy(); df["diagnosis"] = df["target"].map({0: "malignant", 1: "benign"})
stat, p = stats.shapiro(df["mean radius"].sample(200, random_state=1))
print(f"Shapiro-Wilk normality test (n=200): W={stat:.3f}, p={p:.4f}")
u, p = stats.mannwhitneyu(df.loc[df.diagnosis=="malignant","mean area"], df.loc[df.diagnosis=="benign","mean area"])
print(f"Mann-Whitney U on mean area: p={p:.2e}")
res = optimize.minimize(lambda v: (v[0]-3)**2 + (v[1]+1)**2, x0=[0, 0])
print("minimise (x-3)^2+(y+1)^2 ->", np.round(res.x, 3))

# %% [markdown]
# ## 4. scikit-learn: pipeline

# %%
X, y = data.data, data.target
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, stratify=y, random_state=42)
pipe = Pipeline([("scale", StandardScaler()), ("clf", LogisticRegression(max_iter=1000))])
cv = cross_val_score(pipe, Xtr, ytr, cv=5)
pipe.fit(Xtr, ytr)
print("5-fold CV accuracy:", cv.round(3), "mean", round(cv.mean(), 3))
print("test accuracy:", round(accuracy_score(yte, pipe.predict(Xte)), 3))

# %% [markdown]
# ## 5. Matplotlib + Seaborn portfolio dashboard

# %%
fig = plt.figure(figsize=(13, 8)); gs = fig.add_gridspec(2, 3)
ax1 = fig.add_subplot(gs[0, :2]); ax1.plot(sales.date, sales.units, alpha=.4, label="daily"); ax1.plot(sales.date, sales.rolling7, lw=2, label="7-day mean")
ax1.set_title("Pandas time series (units per day)"); ax1.legend()
ax2 = fig.add_subplot(gs[0, 2]); sales.groupby("city").units.sum().plot.bar(ax=ax2, color="#457b9d", rot=0); ax2.set_title("Units by city")
ax3 = fig.add_subplot(gs[1, 0]); sns.kdeplot(data=df, x="mean radius", hue="diagnosis", fill=True, ax=ax3); ax3.set_title("Seaborn KDE")
ax4 = fig.add_subplot(gs[1, 1]); sns.boxplot(data=df, x="diagnosis", y="worst area", ax=ax4); ax4.set_title("Seaborn boxplot")
ax5 = fig.add_subplot(gs[1, 2]); sns.scatterplot(data=df, x="mean radius", y="mean concavity", hue="diagnosis", s=18, ax=ax5); ax5.set_title("Scatter")
plt.tight_layout(); plt.savefig("figures/tool_dashboard.png", dpi=130); plt.show()
