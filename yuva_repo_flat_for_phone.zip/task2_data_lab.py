# %% [markdown]
# # Task 2: Hands-On Data Lab Implementation
# Environment setup, data manipulation, visualization and basic analysis.

# %%
import os, sys, platform
import numpy as np, pandas as pd, matplotlib, seaborn as sns, scipy, sklearn
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
os.makedirs("figures", exist_ok=True)
sns.set_theme(style="whitegrid")

# %% [markdown]
# ## 1. Environment check

# %%
print("Python     :", sys.version.split()[0])
for lib in (np, pd, matplotlib, sns, scipy, sklearn):
    print(f"{lib.__name__:<12}:", lib.__version__)

# %% [markdown]
# ## 2. NumPy exercises

# %%
a = np.arange(1, 13).reshape(3, 4)
print(a)
print("shape:", a.shape, "| sum axis0:", a.sum(axis=0), "| mean axis1:", a.mean(axis=1))
print("a[a % 2 == 0]:", a[a % 2 == 0])
print("a @ a.T:\n", a @ a.T)
rng = np.random.default_rng(42)
r = rng.normal(50, 10, 1000)
print("random normal -> mean %.2f, std %.2f" % (r.mean(), r.std()))

# %% [markdown]
# ## 3. Pandas data manipulation

# %%
raw = load_breast_cancer(as_frame=True)
df = raw.frame.copy()
df["diagnosis"] = df["target"].map({0: "malignant", 1: "benign"})
print(df.shape)
print(df[["mean radius", "mean texture", "mean area", "diagnosis"]].head())

# %%
big = df[df["mean radius"] > 20].sort_values("mean radius", ascending=False)
print("tumours with mean radius > 20:", len(big), "| share malignant:", round((big.diagnosis == "malignant").mean(), 3))
df["size_group"] = pd.cut(df["mean radius"], bins=[0, 12, 15, 40], labels=["small", "medium", "large"])
print(df["size_group"].value_counts())

summary = df.groupby("diagnosis")[["mean radius", "mean texture", "mean area", "mean smoothness"]].agg(["mean", "median", "std"]).round(3)
print(summary.T)

print(pd.crosstab(df["size_group"], df["diagnosis"], normalize="index").round(3))

lookup = pd.DataFrame({"diagnosis": ["malignant", "benign"], "risk_level": ["high", "low"]})
merged = df.merge(lookup, on="diagnosis")
print(merged[["diagnosis", "risk_level"]].value_counts())

# %% [markdown]
# ## 4. Visualization

# %%
fig, ax = plt.subplots(2, 2, figsize=(11, 8))
sns.histplot(df, x="mean radius", hue="diagnosis", kde=True, ax=ax[0, 0]); ax[0, 0].set_title("Histogram of mean radius")
sns.boxplot(df, x="diagnosis", y="mean area", ax=ax[0, 1]); ax[0, 1].set_title("Mean area by diagnosis")
sns.scatterplot(df, x="mean radius", y="mean texture", hue="diagnosis", alpha=.7, ax=ax[1, 0]); ax[1, 0].set_title("Radius vs texture")
df["diagnosis"].value_counts().plot.bar(ax=ax[1, 1], color=["#2a9d8f", "#e76f51"], rot=0); ax[1, 1].set_title("Class counts")
plt.tight_layout(); plt.savefig("figures/lab_plots.png", dpi=130); plt.show()

# %% [markdown]
# ## 5. Basic analysis

# %%
cols = ["mean radius", "mean texture", "mean perimeter", "mean area", "mean smoothness", "mean concavity"]
corr = df[cols].corr().round(2)
print(corr)
plt.figure(figsize=(7, 5.5)); sns.heatmap(corr, annot=True, cmap="coolwarm", vmin=-1, vmax=1)
plt.title("Correlation heatmap"); plt.tight_layout(); plt.savefig("figures/lab_heatmap.png", dpi=130); plt.show()

top = df[df.columns[:30]].corrwith(df["target"]).sort_values()
print("\nTop 5 features most negatively correlated with 'benign' (higher in malignant):")
print(top.head(5).round(3))
